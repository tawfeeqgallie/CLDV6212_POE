using CLDV6212_POE.Models;
namespace CLDV6212_POE.Services
{
    public class InMemoryRepository
    {
        public List<Product> Products { get; } = new List<Product>();
        public List<Customer> Customers { get; } = new List<Customer>();
        public List<Order> Orders { get; } = new List<Order>();

        public InMemoryRepository()
        {
            // Seed with sample data to ensure at least 5 records for screenshots if needed
            for (int i = 1; i <= 5; i++)
            {
                Products.Add(new Product { Name = $"Sample Product {i}", Price = 10 * i, Quantity = 5 + i });
                Customers.Add(new Customer { FirstName = $"First{i}", LastName = $"Last{i}", Email = $"user{i}@example.com" });
            }
        }
    }
}
