using Azure.Data.Tables;
using Azure.Storage.Blobs;
using Azure.Storage.Queues;
using Azure.Storage.Files.Shares;
using CLDV6212_POE.Services;
using Microsoft.Extensions.FileProviders;

var builder = WebApplication.CreateBuilder(args);

// Add services
builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages();
builder.Services.AddSingleton<AzureBlobService>();
builder.Services.AddSingleton<AzureQueueService>();
builder.Services.AddSingleton<AzureTableService>();
builder.Services.AddSingleton<AzureFileService>();
builder.Services.AddSingleton<InMemoryRepository>();

var app = builder.Build();

// Ensure wwwroot/uploads exist for local fallback
var uploads = Path.Combine(app.Environment.ContentRootPath, "wwwroot", "uploads");
Directory.CreateDirectory(uploads);
var contracts = Path.Combine(app.Environment.ContentRootPath, "wwwroot", "uploads", "contracts");
Directory.CreateDirectory(contracts);

// Configure static files
app.UseStaticFiles();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.MapRazorPages();

app.Run();
