using CLDV6212_POE.Models;
using CLDV6212_POE.Services;
using Microsoft.AspNetCore.Mvc;

namespace CLDV6212_POE.Controllers
{
    public class CustomersController : Controller
    {
        private readonly InMemoryRepository _repo;
        public CustomersController(InMemoryRepository repo) => _repo = repo;

        public IActionResult Index() => View(_repo.Customers);

        public IActionResult Create() => View(new Customer());

        [HttpPost]
        public IActionResult Create(Customer model)
        {
            if (!ModelState.IsValid) return View(model);
            _repo.Customers.Add(model);
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Details(string id)
        {
            var c = _repo.Customers.FirstOrDefault(x => x.Id == id);
            if (c == null) return NotFound();
            return View(c);
        }
    }
}
