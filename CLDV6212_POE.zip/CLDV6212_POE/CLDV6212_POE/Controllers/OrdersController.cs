using Azure.Storage.Queues;
using CLDV6212_POE.Models;
using CLDV6212_POE.Services;
using Microsoft.AspNetCore.Mvc;

namespace CLDV6212_POE.Controllers
{
    public class OrdersController : Controller
    {
        private readonly InMemoryRepository _repo;
        private readonly AzureQueueService _queueService;

        public OrdersController(InMemoryRepository repo, AzureQueueService queueService)
        {
            _repo = repo;
            _queueService = queueService;
        }

        public IActionResult Index() => View(_repo.Orders);

        public IActionResult Create() => View(new Order());

        [HttpPost]
        public async Task<IActionResult> Create(Order model)
        {
            if (!ModelState.IsValid) return View(model);

            model.Created = DateTime.UtcNow;
            _repo.Orders.Add(model);

            // Send queue message to notify of new order
            var client = _queueService.GetClient();
            if (client != null)
            {
                var q = client.GetQueueClient("orders");
                await q.CreateIfNotExistsAsync();
                await q.SendMessageAsync($"NewOrder:{model.Id}");
            }
            else
            {
                // Local fallback: nothing required, but safe simulation possible
            }

            return RedirectToAction(nameof(Index));
        }

        public IActionResult Details(string id)
        {
            var o = _repo.Orders.FirstOrDefault(x => x.Id == id);
            if (o == null) return NotFound();
            return View(o);
        }
    }
}
