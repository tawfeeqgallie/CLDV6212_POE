using Azure.Storage.Files.Shares;
using CLDV6212_POE.Services;
using Microsoft.AspNetCore.Mvc;

namespace CLDV6212_POE.Controllers
{
    public class FilesController : Controller
    {
        private readonly AzureFileService _fileService;
        private readonly IWebHostEnvironment _env;
        public FilesController(AzureFileService fileService, IWebHostEnvironment env)
        {
            _fileService = fileService;
            _env = env;
        }

        public IActionResult Index() => View();

        [HttpPost]
        public async Task<IActionResult> Upload(IFormFile file)
        {
            if (file == null || file.Length == 0) return RedirectToAction(nameof(Index));

            var client = _fileService.GetClient();
            var fileName = Guid.NewGuid() + Path.GetExtension(file.FileName);

            if (client != null)
            {
                var share = client.GetShareClient("contracts");
                await share.CreateIfNotExistsAsync();
                var root = share.GetRootDirectoryClient();
                var fc = root.GetFileClient(fileName);
                using var s = file.OpenReadStream();
                await fc.CreateAsync(file.Length);
                await fc.UploadAsync(s);
            }
            else
            {
                var dir = Path.Combine(_env.ContentRootPath, "wwwroot", "uploads", "contracts");
                Directory.CreateDirectory(dir);
                var path = Path.Combine(dir, fileName);
                using var fs = System.IO.File.Create(path);
                await file.CopyToAsync(fs);
            }

            return RedirectToAction(nameof(Index));
        }
    }
}
