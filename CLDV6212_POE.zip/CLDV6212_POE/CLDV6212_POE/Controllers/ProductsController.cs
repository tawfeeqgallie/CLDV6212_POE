using Azure.Storage.Blobs;
using CLDV6212_POE.Models;
using CLDV6212_POE.Services;
using Microsoft.AspNetCore.Mvc;

namespace CLDV6212_POE.Controllers
{
    public class ProductsController : Controller
    {
        private readonly AzureBlobService _blobService;
        private readonly InMemoryRepository _repo;
        private readonly IWebHostEnvironment _env;

        public ProductsController(AzureBlobService blobService, InMemoryRepository repo, IWebHostEnvironment env)
        {
            _blobService = blobService;
            _repo = repo;
            _env = env;
        }

        public IActionResult Index()
        {
            return View(_repo.Products);
        }

        public IActionResult Create() => View(new Product());

        [HttpPost]
        public async Task<IActionResult> Create(Product model, IFormFile? image)
        {
            if (!ModelState.IsValid) return View(model);

            // Upload image to Azure Blob if available, otherwise to wwwroot/uploads
            var blobClient = _blobService.GetClient();
            if (image != null && image.Length > 0)
            {
                var fileName = Guid.NewGuid() + Path.GetExtension(image.FileName);
                if (blobClient != null)
                {
                    var container = blobClient.GetBlobContainerClient("product-images");
                    await container.CreateIfNotExistsAsync();
                    var blob = container.GetBlobClient(fileName);
                    using var stream = image.OpenReadStream();
                    await blob.UploadAsync(stream, overwrite: true);
                    model.ImageUrl = blob.Uri.ToString();
                }
                else
                {
                    var uploads = Path.Combine(_env.ContentRootPath, "wwwroot", "uploads");
                    Directory.CreateDirectory(uploads);
                    var path = Path.Combine(uploads, fileName);
                    using var fs = System.IO.File.Create(path);
                    await image.CopyToAsync(fs);
                    model.ImageUrl = $"/uploads/{fileName}";
                }
            }

            _repo.Products.Add(model);
            // For POE: also write to table storage if available (simplified here)
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Details(string id)
        {
            var p = _repo.Products.FirstOrDefault(x => x.Id == id);
            if (p == null) return NotFound();
            return View(p);
        }
    }
}
